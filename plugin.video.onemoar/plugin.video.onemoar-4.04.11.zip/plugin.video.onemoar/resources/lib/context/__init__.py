# -*- coding: utf-8 -*-
"""
	OneMoar Add-on
"""

contextmenu_properties = [
#	'context.onemoar.settings',
	'context.onemoar.addtoLibrary',
	'context.onemoar.addtoFavourite',
	'context.onemoar.playTrailer',
	'context.onemoar.playTrailerSelect',
	'context.onemoar.traktManager',
	'context.onemoar.clearProviders',
	'context.onemoar.clearBookmark',
	'context.onemoar.rescrape',
	'context.onemoar.playFromHere',
	'context.onemoar.autoPlay',
	'context.onemoar.sourceSelect',
	'context.onemoar.findSimilar',
	'context.onemoar.browseSeries',
	'context.onemoar.browseEpisodes'
]
